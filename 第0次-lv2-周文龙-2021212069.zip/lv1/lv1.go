package main

import  ("fmt")

func main() {
	var a int
	var b int
	var so string
	fmt.Println("input")
	fmt.Scan(&a,&so,&b)
	switch so{
	case "+":fmt.Println(a,so,b,"=",a + b)
	case "-":fmt.Println(a,so,b,"=",a - b)
	case "*":fmt.Println(a,so,b,"=",a * b)
	case "/":fmt.Println(a,so,b,"=",a / b)
	default:
		fmt.Println("error")
	}





}



