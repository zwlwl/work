package main
import ("fmt")
func main() {
	var name string
	var password string
	fmt.Print("请输入用户名：")
	fmt.Scanln(&name)
	fmt.Print("请输入密码：")
    fmt.Scanln(&password)
	if name == "asdf" && password == "werf" {
		fmt.Println("登陆成功")
	}else{
		fmt.Println("用户名或密码错误")
	}

}
