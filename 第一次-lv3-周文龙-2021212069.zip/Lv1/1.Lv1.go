package main

import "fmt"

func main(){
	var s1,s2 string
	fmt.Scan(&s1)
	for _,s1:=range s1{
		var t string
		t=string(s1)
		s2=t+s2
	}
	fmt.Println(s2)
}
