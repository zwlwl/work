package main

import "fmt"
func add(num1,num2 int) int {
	return num1+num2
}
func minus(num1,num2 int) int {
	return num1-num2
}
func mcl(num1,num2 int) int {
	return num1*num2
}

func main() {
	var num1, num2 int
	var his []int
	his = make([]int, 0)
	var ans int
	var cmd string
	for true {
		fmt.Scanln(&num1, &cmd, &num2)
		switch cmd {
		case "+":
			ans = add(num1, num2)
			fmt.Println(ans)
		case "-":
			ans = minus(num1, num2)
			fmt.Println(ans)
		case "*":
			ans = mcl(num1, num2)
			fmt.Println(ans)
		}
		his = append(his, ans)
		for _, hisNum := range his {
			fmt.Print(hisNum, "")
			fmt.Print(" ")
		}

	}
}