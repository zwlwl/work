package main

import (
	"fmt"
	"math/rand"
)
func SortSlice(s []int){
	for i:=0;i<len(s)-1;i++{
		for j:=i+1;j<len(s);j++{
			if s[j]>s[i]{
				s[i],s[j]=s[j],s[i]
			}
		}
	}
}
func main(){
	var s []int
	s=make([]int,0)
	for  i:=0;i<100;i++{
		s=append(s,rand.Int())
	}
	SortSlice(s)
	fmt.Println(s)
}

