package main
import (
	"fmt"
)

type Recommend struct {
	Title []string
}
type Author struct {
	Name string
	Signature string
	VIP bool
	Focus int
	Video Recommend
}
func main(){
	aut:=Author{
		"红岩网校工作站\n",
		"才不是懒得写签名呢\n",
		false,
		199,
		Recommend{
			[]string{"编程×艺术=？用processing打造梦幻作品，你也可以！","这个VSCode扩展居然能让你写代码充满乐趣"}},
	}
	fmt.Println(aut)
}

